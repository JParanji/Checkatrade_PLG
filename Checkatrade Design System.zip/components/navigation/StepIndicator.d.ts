export interface StepIndicatorProps {
  steps?: string[];
  activeIndex?: number;
}
