import React from 'react';

export function StepIndicator({ steps = ['About your business', 'Select lead plan', 'Your details', 'Review & confirm'], activeIndex = 0 }) {
  return React.createElement('div', {
    style: { background: 'var(--color-background-surface-brand-primary-soft)', padding: 'var(--space-8) var(--space-6)', display: 'flex', gap: 'var(--space-8)', fontFamily: 'var(--font-body)' },
  },
    steps.map((s, i) => React.createElement('div', { key: s, style: { flex: 1 } },
      React.createElement('div', { style: { fontWeight: 700, fontSize: 'var(--typography-body-font-size-md)', color: i <= activeIndex ? 'var(--color-ink-body-default)' : 'var(--color-ink-body-subtle)', marginBottom: 8 } }, s),
      React.createElement('div', { style: { height: 6, borderRadius: 'var(--radius-pill)', background: i <= activeIndex ? 'var(--color-blue-500)' : 'var(--color-grey-200)' } })
    ))
  );
}
