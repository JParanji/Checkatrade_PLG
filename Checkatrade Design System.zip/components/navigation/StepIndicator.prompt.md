Sits at the top of every step of the tradesperson sign-up flow, showing progress across the 4 named stages.

```jsx
<StepIndicator activeIndex={0} />
```
