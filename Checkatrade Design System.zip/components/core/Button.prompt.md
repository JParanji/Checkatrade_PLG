Full-width action button used for form submission and plan selection.

```jsx
<Button variant="secondary" size="md">Continue</Button>
<Button variant="primary" size="lg">Search area</Button>
```

Variants: `primary` (crimson — one per screen, highest emphasis, e.g. "Search area"), `secondary` (blue — "Continue", "Select Medium"), `outline` (bordered, e.g. unselected plan CTA "Select Small"), `ghost` (text-only links like "Reset to most popular"). Sizes: `sm` `md` `lg`. Set `disabled` to grey out.
