import React from 'react';

export function IconButton({ icon = 'chevron-right', size = 20, color = 'currentColor', label }) {
  const [svg, setSvg] = React.useState(null);
  React.useEffect(() => {
    let alive = true;
    fetch(`https://unpkg.com/lucide-static@latest/icons/${icon}.svg`)
      .then(r => r.text())
      .then(text => { if (alive) setSvg(text.replace(/stroke="[^"]*"/g, 'stroke="currentColor"')); })
      .catch(() => {});
    return () => { alive = false; };
  }, [icon]);
  return React.createElement('span', {
    role: 'img', 'aria-label': label || icon,
    style: { display: 'inline-flex', width: size, height: size, color },
    dangerouslySetInnerHTML: svg ? { __html: svg } : undefined,
  });
}
