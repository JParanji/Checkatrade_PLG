import React from 'react';

export function Button({ variant = 'primary', size = 'md', disabled = false, children, onClick, type = 'button' }) {
  const sizes = {
    sm: { padding: '8px 14px', fontSize: 'var(--typography-label-font-size-action-sm)' },
    md: { padding: '12px 20px', fontSize: 'var(--typography-label-font-size-action-md)' },
    lg: { padding: '16px 24px', fontSize: 'var(--typography-label-font-size-action-lg)' },
  };
  const variants = {
    primary: { background: 'var(--color-background-action-brand-secondary)', color: '#fff', border: '1px solid transparent' },
    secondary: { background: 'var(--color-background-action-brand-primary)', color: '#fff', border: '1px solid transparent' },
    outline: { background: '#fff', color: 'var(--color-ink-body-brand)', border: '1px solid var(--color-border-default)' },
    ghost: { background: 'transparent', color: 'var(--color-ink-body-brand)', border: '1px solid transparent' },
  };
  const style = {
    fontFamily: 'var(--font-body)', fontWeight: 700, borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1,
    width: '100%', textAlign: 'center',
    ...sizes[size], ...variants[variant],
  };
  return React.createElement('button', { type, disabled, onClick, style }, children);
}
