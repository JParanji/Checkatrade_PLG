export interface IconButtonProps {
  /** Lucide icon name, e.g. "search", "chevron-right" — substitute icon set, see readme Iconography */
  icon?: string;
  size?: number;
  color?: string;
  label?: string;
}
