Renders a single glyph from the Lucide substitute icon set (CDN), masked to any ink colour — used for the search glyph and row chevrons.

```jsx
<IconButton icon="search" color="var(--color-ink-body-subtle)" />
<IconButton icon="chevron-right" />
```

Only `search` and `chevron-right` were observed in the source screenshots; any Lucide name works.
