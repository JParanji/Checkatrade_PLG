export interface ButtonProps {
  /** Visual style: primary = crimson high-emphasis CTA, secondary = blue product action, outline, ghost */
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  type?: 'button' | 'submit';
  onClick?: () => void;
  children: React.ReactNode;
}
