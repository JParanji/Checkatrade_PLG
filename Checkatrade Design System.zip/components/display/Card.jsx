import React from 'react';

export function Card({ highlighted = false, children, style }) {
  return React.createElement('div', {
    style: {
      background: '#fff', borderRadius: 'var(--radius-lg)', padding: 'var(--space-6)',
      border: highlighted ? '2px solid var(--color-blue-500)' : '1px solid var(--color-border-default)',
      boxShadow: highlighted ? 'var(--shadow-card-raised)' : 'var(--shadow-card)',
      fontFamily: 'var(--font-body)', position: 'relative',
      ...style,
    },
  }, children);
}
