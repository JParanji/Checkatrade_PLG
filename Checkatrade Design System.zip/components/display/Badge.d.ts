export interface BadgeProps {
  children?: React.ReactNode;
  tone?: 'brand' | 'neutral';
}
