import React from 'react';

export function Badge({ children = 'Recommended', tone = 'brand' }) {
  const tones = {
    brand: { background: 'var(--color-blue-500)', color: '#fff' },
    neutral: { background: 'var(--color-grey-100)', color: 'var(--color-ink-body-default)' },
  };
  return React.createElement('span', {
    style: {
      display: 'inline-block', padding: '6px 16px', borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: 'var(--typography-label-font-size-action-sm)',
      ...tones[tone],
    },
  }, children);
}
