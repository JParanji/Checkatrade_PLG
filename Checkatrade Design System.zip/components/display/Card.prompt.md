Generic surface for pricing plans, list rows, and grouped content.

```jsx
<Card highlighted><Badge>Recommended</Badge>...</Card>
```
