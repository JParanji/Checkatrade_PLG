Small pill label, e.g. the "Recommended" ribbon on the middle pricing plan.

```jsx
<Badge>Recommended</Badge>
```
