export interface CardProps {
  /** Highlighted = 2px blue ring + raised shadow, e.g. the "Recommended" plan */
  highlighted?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
