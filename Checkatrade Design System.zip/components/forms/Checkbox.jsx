import React from 'react';

export function Checkbox({ checked = false, label, onChange }) {
  return React.createElement('label', {
    style: {
      display: 'flex', alignItems: 'center', gap: 12, padding: '16px', cursor: 'pointer',
      border: '1px solid var(--color-border-default)', borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-body)', fontSize: 'var(--typography-body-font-size-lg)', color: 'var(--color-ink-body-default)',
    },
  },
    React.createElement('span', {
      style: {
        width: 22, height: 22, borderRadius: 5, flexShrink: 0,
        background: checked ? 'var(--color-background-action-brand-primary)' : '#fff',
        border: checked ? 'none' : '1px solid var(--color-border-strong)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 13,
      },
    }, checked ? '✓' : ''),
    React.createElement('input', { type: 'checkbox', checked, onChange, style: { display: 'none' } }),
    label
  );
}
