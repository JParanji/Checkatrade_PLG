export interface SliderProps {
  steps?: string[];
  activeIndex?: number;
  onChange?: (index: number) => void;
}
