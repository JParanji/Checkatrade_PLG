export interface InputProps {
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Adds leading search icon, as in "Search services" */
  search?: boolean;
  /** Shows a trailing green check (true) or red border (false) */
  valid?: boolean;
  iconRight?: React.ReactNode;
}
