Discrete-step slider for the search-radius picker (1/2/5/10/15/25/50 miles).

```jsx
<Slider activeIndex={2} onChange={setIndex} />
```
