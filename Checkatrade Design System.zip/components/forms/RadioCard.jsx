import React from 'react';

export function RadioCard({ selected = false, icon, label, onClick }) {
  return React.createElement('button', {
    type: 'button', onClick,
    style: {
      display: 'flex', alignItems: 'center', gap: 12, width: '100%', textAlign: 'left',
      padding: '16px', cursor: 'pointer', background: '#fff',
      border: `1px solid ${selected ? 'var(--color-border-action-brand-secondary)' : 'var(--color-border-default)'}`,
      borderRadius: 'var(--radius-md)', fontFamily: 'var(--font-body)',
    },
  },
    React.createElement('span', {
      style: {
        width: 20, height: 20, borderRadius: '50%', flexShrink: 0,
        border: `2px solid ${selected ? 'var(--color-blue-400)' : 'var(--color-border-strong)'}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      },
    }, selected && React.createElement('span', { style: { width: 10, height: 10, borderRadius: '50%', background: 'var(--color-blue-400)' } })),
    icon && React.createElement('span', { style: { width: 36, height: 36, borderRadius: 8, background: 'var(--color-blue-50)', display: 'flex', alignItems: 'center', justifyContent: 'center' } }, icon),
    React.createElement('span', { style: { fontWeight: 600, color: selected ? 'var(--color-blue-500)' : 'var(--color-ink-body-default)', fontSize: 'var(--typography-body-font-size-lg)' } }, label)
  );
}
