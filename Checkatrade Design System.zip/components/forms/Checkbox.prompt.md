Full-row checkbox as seen in "What type of Painter/Decorator work would you like?" — the whole row is the tap target, not just the box.

```jsx
<Checkbox checked label="Exterior Painting" />
```
