export interface RadioCardProps {
  selected?: boolean;
  icon?: React.ReactNode;
  label: React.ReactNode;
  onClick?: () => void;
}
