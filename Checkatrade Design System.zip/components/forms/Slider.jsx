import React from 'react';

export function Slider({ steps = ['1 mile', '2 miles', '5 miles', '10 miles', '15 miles', '25 miles', '50 miles'], activeIndex = 2, onChange }) {
  const pct = (activeIndex / (steps.length - 1)) * 100;
  return React.createElement('div', { style: { fontFamily: 'var(--font-body)' } },
    React.createElement('div', { style: { position: 'relative', height: 4, background: 'var(--color-border-default)', borderRadius: 'var(--radius-pill)', margin: '10px 0' } },
      React.createElement('div', { style: { position: 'absolute', left: 0, top: 0, height: 4, width: pct + '%', background: 'var(--color-blue-500)', borderRadius: 'var(--radius-pill)' } }),
      steps.map((s, i) => React.createElement('button', {
        key: s, type: 'button', onClick: () => onChange && onChange(i),
        style: {
          position: 'absolute', top: '50%', left: (i / (steps.length - 1)) * 100 + '%',
          transform: 'translate(-50%,-50%)', width: 16, height: 16, borderRadius: '50%',
          background: i <= activeIndex ? 'var(--color-blue-500)' : '#fff',
          border: `2px solid ${i <= activeIndex ? 'var(--color-blue-500)' : 'var(--color-border-strong)'}`, cursor: 'pointer', padding: 0,
        },
      }))
    ),
    React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: 'var(--typography-body-font-size-sm)', color: 'var(--color-ink-body-subtle)' } },
      steps.map(s => React.createElement('span', { key: s }, s))
    )
  );
}
