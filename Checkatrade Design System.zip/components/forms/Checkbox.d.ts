export interface CheckboxProps {
  checked?: boolean;
  label: React.ReactNode;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}
