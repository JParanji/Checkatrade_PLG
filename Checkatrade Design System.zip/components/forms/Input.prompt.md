Text field with optional leading search icon and trailing validation check — used for postcode/business-name fields and the service search box.

```jsx
<Input search placeholder="Search services" />
<Input placeholder="W14 9ES" valid={true} />
```
