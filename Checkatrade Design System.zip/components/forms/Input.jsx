import React from 'react';
import { IconButton } from '../core/IconButton.jsx';

export function Input({ placeholder, value, onChange, search = false, valid, iconRight }) {
  return React.createElement('div', { style: { position: 'relative' } },
    search && React.createElement('span', { style: { position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' } },
      React.createElement(IconButton, { icon: 'search', color: 'var(--color-ink-body-subtle)', size: 18 })),
    React.createElement('input', {
      placeholder, value, onChange,
      style: {
        width: '100%', boxSizing: 'border-box', fontFamily: 'var(--font-body)',
        fontSize: 'var(--typography-body-font-size-lg)', color: 'var(--color-ink-body-default)',
        padding: search ? '14px 44px' : '14px 16px',
        border: `1px solid ${valid === false ? 'var(--color-crimson-400)' : 'var(--color-border-default)'}`,
        borderRadius: 'var(--radius-md)', outline: 'none',
      },
    }),
    valid === true && React.createElement('span', { style: { position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', width: 22, height: 22, borderRadius: '50%', background: '#1c7a3c', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13 } }, '✓')
  );
}
