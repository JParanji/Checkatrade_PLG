Full-row single-select radio, used for "Business type: Self Employed". Selected state swaps the border to blue and tints the label text blue rather than filling the whole row.

```jsx
<RadioCard selected label="Self Employed" icon={<IconButton icon="user" />} />
```
