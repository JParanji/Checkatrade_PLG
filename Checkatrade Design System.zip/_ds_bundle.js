/* @ds-bundle: {"format":4,"namespace":"CheckatradeDesignSystem_9d5132","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"RadioCard","sourcePath":"components/forms/RadioCard.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"StepIndicator","sourcePath":"components/navigation/StepIndicator.jsx"}],"sourceHashes":{"components/core/Button.jsx":"7d5896c005b5","components/core/IconButton.jsx":"3566c6646893","components/display/Badge.jsx":"ef59d02f882b","components/display/Card.jsx":"cdd6a5f63448","components/forms/Checkbox.jsx":"e4b5657bc15c","components/forms/Input.jsx":"0dafe282c216","components/forms/RadioCard.jsx":"b64db61e70ad","components/forms/Slider.jsx":"3bb54dc57f28","components/navigation/StepIndicator.jsx":"dd337753f749"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CheckatradeDesignSystem_9d5132 = window.CheckatradeDesignSystem_9d5132 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  children,
  onClick,
  type = 'button'
}) {
  const sizes = {
    sm: {
      padding: '8px 14px',
      fontSize: 'var(--typography-label-font-size-action-sm)'
    },
    md: {
      padding: '12px 20px',
      fontSize: 'var(--typography-label-font-size-action-md)'
    },
    lg: {
      padding: '16px 24px',
      fontSize: 'var(--typography-label-font-size-action-lg)'
    }
  };
  const variants = {
    primary: {
      background: 'var(--color-background-action-brand-secondary)',
      color: '#fff',
      border: '1px solid transparent'
    },
    secondary: {
      background: 'var(--color-background-action-brand-primary)',
      color: '#fff',
      border: '1px solid transparent'
    },
    outline: {
      background: '#fff',
      color: 'var(--color-ink-body-brand)',
      border: '1px solid var(--color-border-default)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--color-ink-body-brand)',
      border: '1px solid transparent'
    }
  };
  const style = {
    fontFamily: 'var(--font-body)',
    fontWeight: 700,
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    width: '100%',
    textAlign: 'center',
    ...sizes[size],
    ...variants[variant]
  };
  return React.createElement('button', {
    type,
    disabled,
    onClick,
    style
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function IconButton({
  icon = 'chevron-right',
  size = 20,
  color = 'currentColor',
  label
}) {
  const [svg, setSvg] = React.useState(null);
  React.useEffect(() => {
    let alive = true;
    fetch(`https://unpkg.com/lucide-static@latest/icons/${icon}.svg`).then(r => r.text()).then(text => {
      if (alive) setSvg(text.replace(/stroke="[^"]*"/g, 'stroke="currentColor"'));
    }).catch(() => {});
    return () => {
      alive = false;
    };
  }, [icon]);
  return React.createElement('span', {
    role: 'img',
    'aria-label': label || icon,
    style: {
      display: 'inline-flex',
      width: size,
      height: size,
      color
    },
    dangerouslySetInnerHTML: svg ? {
      __html: svg
    } : undefined
  });
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
function Badge({
  children = 'Recommended',
  tone = 'brand'
}) {
  const tones = {
    brand: {
      background: 'var(--color-blue-500)',
      color: '#fff'
    },
    neutral: {
      background: 'var(--color-grey-100)',
      color: 'var(--color-ink-body-default)'
    }
  };
  return React.createElement('span', {
    style: {
      display: 'inline-block',
      padding: '6px 16px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 'var(--typography-label-font-size-action-sm)',
      ...tones[tone]
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function Card({
  highlighted = false,
  children,
  style
}) {
  return React.createElement('div', {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-6)',
      border: highlighted ? '2px solid var(--color-blue-500)' : '1px solid var(--color-border-default)',
      boxShadow: highlighted ? 'var(--shadow-card-raised)' : 'var(--shadow-card)',
      fontFamily: 'var(--font-body)',
      position: 'relative',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  checked = false,
  label,
  onChange
}) {
  return React.createElement('label', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '16px',
      cursor: 'pointer',
      border: '1px solid var(--color-border-default)',
      borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--typography-body-font-size-lg)',
      color: 'var(--color-ink-body-default)'
    }
  }, React.createElement('span', {
    style: {
      width: 22,
      height: 22,
      borderRadius: 5,
      flexShrink: 0,
      background: checked ? 'var(--color-background-action-brand-primary)' : '#fff',
      border: checked ? 'none' : '1px solid var(--color-border-strong)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      fontSize: 13
    }
  }, checked ? '✓' : ''), React.createElement('input', {
    type: 'checkbox',
    checked,
    onChange,
    style: {
      display: 'none'
    }
  }), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  placeholder,
  value,
  onChange,
  search = false,
  valid,
  iconRight
}) {
  return React.createElement('div', {
    style: {
      position: 'relative'
    }
  }, search && React.createElement('span', {
    style: {
      position: 'absolute',
      left: 14,
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }, React.createElement(__ds_scope.IconButton, {
    icon: 'search',
    color: 'var(--color-ink-body-subtle)',
    size: 18
  })), React.createElement('input', {
    placeholder,
    value,
    onChange,
    style: {
      width: '100%',
      boxSizing: 'border-box',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--typography-body-font-size-lg)',
      color: 'var(--color-ink-body-default)',
      padding: search ? '14px 44px' : '14px 16px',
      border: `1px solid ${valid === false ? 'var(--color-crimson-400)' : 'var(--color-border-default)'}`,
      borderRadius: 'var(--radius-md)',
      outline: 'none'
    }
  }), valid === true && React.createElement('span', {
    style: {
      position: 'absolute',
      right: 14,
      top: '50%',
      transform: 'translateY(-50%)',
      width: 22,
      height: 22,
      borderRadius: '50%',
      background: '#1c7a3c',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 13
    }
  }, '✓'));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioCard.jsx
try { (() => {
function RadioCard({
  selected = false,
  icon,
  label,
  onClick
}) {
  return React.createElement('button', {
    type: 'button',
    onClick,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      width: '100%',
      textAlign: 'left',
      padding: '16px',
      cursor: 'pointer',
      background: '#fff',
      border: `1px solid ${selected ? 'var(--color-border-action-brand-secondary)' : 'var(--color-border-default)'}`,
      borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-body)'
    }
  }, React.createElement('span', {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      flexShrink: 0,
      border: `2px solid ${selected ? 'var(--color-blue-400)' : 'var(--color-border-strong)'}`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, selected && React.createElement('span', {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--color-blue-400)'
    }
  })), icon && React.createElement('span', {
    style: {
      width: 36,
      height: 36,
      borderRadius: 8,
      background: 'var(--color-blue-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, icon), React.createElement('span', {
    style: {
      fontWeight: 600,
      color: selected ? 'var(--color-blue-500)' : 'var(--color-ink-body-default)',
      fontSize: 'var(--typography-body-font-size-lg)'
    }
  }, label));
}
Object.assign(__ds_scope, { RadioCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
function Slider({
  steps = ['1 mile', '2 miles', '5 miles', '10 miles', '15 miles', '25 miles', '50 miles'],
  activeIndex = 2,
  onChange
}) {
  const pct = activeIndex / (steps.length - 1) * 100;
  return React.createElement('div', {
    style: {
      fontFamily: 'var(--font-body)'
    }
  }, React.createElement('div', {
    style: {
      position: 'relative',
      height: 4,
      background: 'var(--color-border-default)',
      borderRadius: 'var(--radius-pill)',
      margin: '10px 0'
    }
  }, React.createElement('div', {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      height: 4,
      width: pct + '%',
      background: 'var(--color-blue-500)',
      borderRadius: 'var(--radius-pill)'
    }
  }), steps.map((s, i) => React.createElement('button', {
    key: s,
    type: 'button',
    onClick: () => onChange && onChange(i),
    style: {
      position: 'absolute',
      top: '50%',
      left: i / (steps.length - 1) * 100 + '%',
      transform: 'translate(-50%,-50%)',
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: i <= activeIndex ? 'var(--color-blue-500)' : '#fff',
      border: `2px solid ${i <= activeIndex ? 'var(--color-blue-500)' : 'var(--color-border-strong)'}`,
      cursor: 'pointer',
      padding: 0
    }
  }))), React.createElement('div', {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 'var(--typography-body-font-size-sm)',
      color: 'var(--color-ink-body-subtle)'
    }
  }, steps.map(s => React.createElement('span', {
    key: s
  }, s))));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/navigation/StepIndicator.jsx
try { (() => {
function StepIndicator({
  steps = ['About your business', 'Select lead plan', 'Your details', 'Review & confirm'],
  activeIndex = 0
}) {
  return React.createElement('div', {
    style: {
      background: 'var(--color-background-surface-brand-primary-soft)',
      padding: 'var(--space-8) var(--space-6)',
      display: 'flex',
      gap: 'var(--space-8)',
      fontFamily: 'var(--font-body)'
    }
  }, steps.map((s, i) => React.createElement('div', {
    key: s,
    style: {
      flex: 1
    }
  }, React.createElement('div', {
    style: {
      fontWeight: 700,
      fontSize: 'var(--typography-body-font-size-md)',
      color: i <= activeIndex ? 'var(--color-ink-body-default)' : 'var(--color-ink-body-subtle)',
      marginBottom: 8
    }
  }, s), React.createElement('div', {
    style: {
      height: 6,
      borderRadius: 'var(--radius-pill)',
      background: i <= activeIndex ? 'var(--color-blue-500)' : 'var(--color-grey-200)'
    }
  }))));
}
Object.assign(__ds_scope, { StepIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/StepIndicator.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.RadioCard = __ds_scope.RadioCard;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.StepIndicator = __ds_scope.StepIndicator;

})();
