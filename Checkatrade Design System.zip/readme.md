# Checkatrade Design System

Checkatrade is a UK online marketplace connecting homeowners with vetted, reviewed tradespeople (plumbers, electricians, builders, roofers, painters/decorators, carpenters, and more). Founded 1998, headquartered in London/Portsmouth. Two audiences use Checkatrade products: **homeowners** searching for and booking trades, and **tradespeople** (the "member" side) who sign up, pay for lead-generation plans, and manage jobs/enquiries.

This design system was built from:
- 5 real product screenshots of the tradesperson-facing sign-up / "get quotes" flow (`uploads/`): category picker, business details form (name, postcode, map radius), work-type checklist, area/radius picker with map, and a 3-tier pricing plan comparison.
- The public Checkatrade Design System site, **checkatrade.design** (Colours, Typography, and Brand sections were readable and used directly — see citations below). No Figma or codebase was attached to this project.

No codebase or Figma file was attached — if you have access to either, attach it (Import menu) so components and screens can be rebuilt from source rather than screenshots.

**Sources (not guaranteed accessible to future readers):**
- https://www.checkatrade.design/ — design system home
- https://www.checkatrade.design/tokens/colors — semantic + primitive colour token names
- https://www.checkatrade.design/tokens/typography — Degular Display / Haffer type scale
- https://www.checkatrade.design/brand/colour — marketing primary palette (exact hex)
- https://www.checkatrade.design/brand/typography — typeface rationale, weights, fallback fonts
- Figma Foundations: https://www.figma.com/design/Kwdf40HLM0Cs9ZLG98D2hn/Foundations
- Figma Components: https://www.figma.com/design/OT6cYQnv8vMf4Q5vbHpETs/Web
- Main site: https://www.checkatrade.com

## Index

- `styles.css` — root stylesheet, imports everything below
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css` (radii/shadow), `fonts.css`
- `guidelines/` — foundation specimen cards shown in the Design System tab
- `components/` — reusable UI primitives (see list below)
- `ui_kits/trade-signup/` — the tradesperson quote-plan sign-up flow, recreated as a clickable prototype
- `assets/logo/checkatrade-logo.png` — logo, cropped directly from a real product screenshot (no vector logo file was provided)
- `SKILL.md` — portable skill definition for use in Claude Code

### Components
- `components/core/Button.jsx` — primary / secondary / ghost, sizes, disabled
- `components/core/IconButton.jsx`
- `components/forms/Input.jsx` — text input with search variant and validation state
- `components/forms/Checkbox.jsx`
- `components/forms/RadioCard.jsx` — the bordered, icon-led radio row seen in the business-type step
- `components/forms/Slider.jsx` — stepped range slider (radius picker)
- `components/display/Badge.jsx` — "Recommended" pill
- `components/display/Card.jsx` — plan / list-row card
- `components/navigation/StepIndicator.jsx` — 4-step progress header

**Intentional additions:** none beyond what the screenshots show, except `IconButton` (a thin wrapper needed to render the chevron/search glyphs consistently) and `Card` (a generic container the pricing and category rows both reduce to).

## Content fundamentals

Direct, plain, instructional. Copy leads with the customer's task, not the brand: *"What type of work do you do?"*, *"Which area would you like to work in?"*, *"Tell us more about your business."* Questions are phrased in second person ("you"), sentences are short, and there's no attempt at cleverness or wit — this is a transactional funnel, not a brand moment.

- **Casing:** sentence case throughout (headings, buttons, labels) — "Search services", "Select Medium", "Reset to most popular" — never Title Case or ALL CAPS except very short pill badges ("Recommended" is still sentence case, just single word).
- **Voice:** second person, present tense, encouraging but matter-of-fact. "We've pre-selected the most popular types of work, but you can change them as needed" — explains a default and hands control back to the user in one plain sentence.
- **Buttons/CTAs:** verb-first and specific — "Search area", "Select Medium", "Continue" — never vague ("Submit", "Next" is used but paired with clear step context via the stepper).
- **Numbers and money:** UK formatting, £ with "/month + VAT" spelled out; ranges given plainly ("49–70 leads estimated annually") rather than rounded to a single flattering number.
- **No emoji.** No exclamation-heavy marketing language in-product. Marketing/brand pages likely allow more warmth ("A job done right." is the brand's stated typography sample line) but the transactional flow stays neutral and efficient.
- **Trust cues in copy:** phone number and opening hours placed top-right on every step ("Call us now on 02394 317546 — Lines open 8am–8pm, Mon–Fri, 10am–4pm Sat–Sun") — always-visible human fallback, characteristic of a marketplace that sells trust as its core product.

## Visual foundations

- **Colour:** White canvas, two accent colours doing all the work — a confident mid-blue (`#0158a2`, product primary/progress/links) and a crimson-red for the single highest-emphasis action per screen (`#d10a38`, e.g. "Search area"). This matches the brand's own description of itself as "a red, blue and white brand." Marketing/brand contexts use a brighter, more saturated red/blue pair (`#ff3f3f` / `#5263ff`) than the product UI, which mutes both into deeper, more legible tones for extended on-screen use. Never more than one strong accent colour competes for attention on a single screen — blue is used for structural/progress/informational actions, red or crimson for the single primary conversion action.
- **Type:** Two-typeface system. Degular Display (Black/Bold) for headlines — geometric, rounded, warm. Haffer (Regular/Medium/Bold) for everything else — body copy, labels, buttons, form fields. In-product headings ("What type of work do you do?") read closer to the Header scale than full Headline scale; Headline is reserved for marketing-weight moments.
- **Spacing:** Generous vertical rhythm between form sections (roughly 32–48px), tighter internal card padding (16–24px). Full-width stacked rows rather than dense grids — one decision per row (category, work-type checkbox, plan tier) so a small-screen or unconfident user is never asked to parse a table.
- **Backgrounds:** Flat white body background throughout the flow. One soft pale-blue panel (`#f8f9ff`-ish) houses the step-indicator strip, setting it apart as chrome rather than content. No photography as backgrounds; category rows use small square photographic thumbnails (a hand sanding wood, a paint roller, roof tiles) — real trade imagery, not stock-abstract. No gradients, no illustration, no texture/pattern anywhere in the product flow.
- **Animation:** Not observable from static screenshots — treat as minimal/functional (standard native map pan/zoom, checkbox toggle, slider drag) rather than expressive; nothing in the captured screens suggests bespoke motion design.
- **Hover / press states:** Not captured in static screenshots. Recommend following standard token pattern already visible in the palette: hover = one step darker on the ramp (`--color-background-action-brand-primary-hover`), press = darker still or a slight scale/opacity dip. Flag this as inferred, not observed.
- **Borders:** Thin 1px light-grey borders (`--color-border-default`) define every input, row, and unselected card — the system relies on borders + selection color rather than shadow for most affordance.
- **Shadows:** Very restrained. Plan cards on the pricing step show a faint ambient shadow; the recommended (middle) plan swaps shadow for a 2px solid blue ring instead of a stronger shadow. Everyday rows (category list, checklist) use border only, no shadow.
- **Corner radii:** Small and consistent — inputs and list rows ~8px, cards ~12px, the step-indicator track and "Recommended" badge are fully pill-rounded. Nothing sharp-cornered, nothing heavily rounded/bubbly.
- **Transparency / blur:** None observed — every surface is opaque.
- **Imagery tone:** The few photographic thumbnails present are warm, natural-light, on-the-job trade photography (timber, paint, roof tile, real hands at work) — no filters, no black-and-white, no heavy grain.
- **Layout rules:** A persistent header (logo left, phone number + hours right) and step-indicator are fixed at the top of every step in the sign-up flow — the user always knows how to escalate to a human and where they are in the funnel. Primary content is a single centred column, generously margined, never edge-to-edge.
- **Cards:** White fill, 1px border by default; selection state swaps the border for a 2px brand-blue outline (business-type card) or adds a "Recommended" ribbon + ring (pricing card) rather than changing the fill colour.

## Iconography

Only two icon-adjacent elements appear across the captured screens: a magnifying-glass search glyph and a right-chevron on list rows. Both read as a standard outline icon set (weight and proportions consistent with something like Lucide/Heroicons-outline) rather than a custom icon font — no custom glyphs, no emoji, no unicode-character icons observed anywhere in the flow. Photographic thumbnails are used instead of icons to represent trade categories (a deliberate choice: real work over abstract iconography). Because no icon SVG/font asset was included in the provided materials, this system links **Lucide** from CDN as the closest neutral match; flagged as a substitution — swap for Checkatrade's real icon set (see Iconography page at checkatrade.design/brand/iconography) if you can access it.

## Caveats & open questions

- **No Figma or codebase attached.** Everything here is reconstructed from 5 screenshots of one flow (tradesperson sign-up) plus the public checkatrade.design brand/token pages. Other surfaces (homeowner search/booking flow, the marketing site, the native app) are undocumented — please attach source material if you'd like those covered.
- **Fonts are substituted.** Real faces are Degular Display and Haffer (both commercial). This system uses Plus Jakarta Sans + Inter as free stand-ins. Please share the real webfont files if you have licensed access.
- **Icons are substituted** with Lucide (CDN) — no real icon asset was available to copy.
- **Hover/press/animation behaviour is inferred**, not observed, since screenshots are static.
- **Exact primitive colour-ramp stops** (Grey/Red/Blue/Crimson 50–1000) weren't readable from the token page (names only, no values) — ramps here are interpolated from the confirmed hex values that were readable (brand palette page + pixel-sampling the product screenshots) and should be replaced with the real `@checkatrade/tokens` values if you can share that package or a Figma variables export.

**Ask:** tell me which of these gaps matters most — real fonts, real icons, the homeowner-facing flow, or a Figma/codebase connection — and I'll iterate toward parity with the real system.
